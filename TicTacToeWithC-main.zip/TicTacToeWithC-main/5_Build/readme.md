This is a build folder. It contains build files of both Linux and Windows that have been created on my local machine.

|          File name         	|                      Description                     	|
|:--------------------------:	|:----------------------------------------------------:	|
|        TicTacToe.exe       	| Build File created on windows OS with .exe extension 	|
|          TicTacToe.out      |        Build file created on Linux with .out extension|             	|
