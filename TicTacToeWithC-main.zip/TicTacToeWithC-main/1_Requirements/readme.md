# Requirements
## Introduction
This is Tic Tac Toe Game desiged in C Programming Language using multifile approach. I have used the concepts of functions and arrays.
This game is a simple game with two players who play to beat each other. It is 3x3 grid game which is played with pen and paper. It is solved game with three definate results two being wins of two players and one being the draw game assuming that both players play best. The player which succeeds to place 3 pieces of same type vertically, horizontally and diagonally he wins the game.
## Research
This game dates backs to the Roman empire around first century BC which was played using only three pebbles.The first print reference to "noughts and crosses" (nought being an alternative word for zero), the British name, appeared in 1858, in an issue of Notes and Queries. The first print reference to a game called "tick-tack-toe" occurred in 1884, but referred to "a children's game played on a slate, consisting in trying with the eyes shut to bring the pencil down on one of the numbers of a set, the number hit being scored".
## Cost and Features
Main features of this game are that it can be played by the user any number of times. After the end of each game user is asked if he want to play it again. 
It uses minimal disk space and memory because it is a console application and can be run on any low end computer easily compared to other high end graphical games which require more memory and disk space.
Easy to understand game interface and can be played by anyone.
Cross Platform application that can be used on any operating system by building it according to the needs.
## Defining Our System
Our system is a computer program to play a tic tac toe game designed using the C programming language. This Program uses different concepts of C programming like 2D arrays, functions, loops, and if statements. 
The requirement and design of this program is done from scratch. It is tested using the unity test Framework designed for the C programming language. It is a cross-platform program that can be compiled and run on any operating system by compiling it on that operating system. 
It is designed by using multiple files so that process can be easily understood by anyone.
## SWOT ANALYSIS
![SWOT](https://user-images.githubusercontent.com/54026778/114148218-2781c880-9937-11eb-9eca-7f6bae303199.jpg)
## 4W&#39;s and 1&#39;H
## Who
This game can be designed for the user base who wants to play Tic-Tac-Toe without the clutter of Graphical user interfaces. 
## What
This is a simple 3x3 board Tic-Tac-Toe game developed in C language for casual playing.
## When
This project will be developed from 6 april to 15 April 2021.
## Where
This project will take place virtually on GitHub and only developed by me
## How
This project will use concepts of basic concepts of C programming language like Loops, If stataments and other advanced concepts like multifile approach, 2D arrays, functions with parameters and other basic input and output functions.
## High Level Requirements
|   ID  	|                                Description                                	|    Status   	|
|:-----:	|:-------------------------------------------------------------------------:	|:-----------:	|
| HL_01 	|         Player should be able to see the status of grid after move        	| Implemented 	|
| HL_02 	| Player should be able to make moves by giving input in form of row-column 	| Implemented 	|
| HL_03 	|           Player should be able to start new game after one ends          	| Implemented 	|
| HL_04 	|             Player can play with the computer if he chooses to            	|    Future   	|
##  Low level Requirements
|   ID  	|                                    Description                                    	|    Status   	|
|:-----:	|:---------------------------------------------------------------------------------:	|:-----------:	|
| LL_01 	|                 Program should check if player one after each move                	| Implemented 	|
| LL_02 	| Game should check for all conditions for a win that is columns,rows and diagonals 	| Implemented 	|
| LL_03 	|  Game should if grid is full after each move, so that it can declare game as draw 	| Implemented 	|
| LL_04 	|            Game should check if inputs of the user are in defined bound           	| Implemented 	|
| LL_05 	|         Game should clear the grid and start a new game if user desires so        	| Implemented 	|
| LL_06 	|                    Game should change the turn after each move                    	| Implemented 	|
