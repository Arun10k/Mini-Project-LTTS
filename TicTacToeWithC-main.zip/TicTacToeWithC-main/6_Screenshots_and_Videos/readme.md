## Names and description of the screenshots and video

|            File name  	|                                      Description                 	|
|:---------------------:	|:----------------------------------------------------------------:	|
|    start_screen.jpg   	| Start screen that is visible to any player when he starts a game 	|
|    game_screen.jgp    	|                 Screenshot of a game in progress                 	|
| player_win_screen.jpg 	|       Screenshot when a player won and message is displayed      	|
|  game_draw_screen.jpg 	|                   Screenshot when game is drawn                  	|
| play_again_screen.jpg 	|                Screenshot to select to play again                	|
|   game_recording.mp4  	|                    Video of game in progress                     	|
